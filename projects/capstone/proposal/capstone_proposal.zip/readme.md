# Machine Learning Engineer Nanodegree
## Specializations
## Project: Capstone Proposal and Capstone Project

**Note**
The data for the project is being hosted in my AWS S3 bucket located at <https://s3.us-east-2.amazonaws.com/mcfalls.me/mlnd_data/mens-machine-learning-competition-2019_src.zip> and is approxiately 202 MBs in size.